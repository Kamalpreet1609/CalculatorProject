//
//  ViewController.swift
//  Calculator
//
//  Created by user185484 on 11/13/20.
//

import UIKit


enum Operation: String{
    case Add = "+"
    case Subtract = "-"
    case Division = "/"
    case multiply = "*"
    case percent = "%"
    case Null = "Null"
}

class ViewController: UIViewController {

    @IBOutlet weak var outputLbl: UILabel!
    
    var runningNumber = ""
    var leftValue = ""
    var rightValue = ""
    var result = ""
    var currentOperation: Operation = .Null
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        outputLbl.text = "0"
    }

    @IBAction func NumberPressed(_ sender: UIButton)
    {
        if runningNumber.count <= 8{
        runningNumber += "\(sender.tag)"
        outputLbl.text = runningNumber
        }
    }
    
     //    runningNumber += "\(sender.tag)"
      //  outputLbl.text = runningNumber
   
    @IBAction func AllClr(_ sender: UIButton) {
        runningNumber = ""
        leftValue = ""
        rightValue = ""
        result = ""
        currentOperation = .Null
        outputLbl.text = "0"
        
    }
    
    @IBAction func DotPressed(_ sender: UIButton) {
        if runningNumber.count <= 7 {
            runningNumber += "."
        outputLbl.text = runningNumber
        }
    }
    
    @IBAction func EqualPressed(_ sender: UIButton) {
        
        operation(operation: currentOperation)
    }

    @IBAction func AddPressed(_ sender: UIButton) {
        
        operation(operation: .Add)
    }
    
    
    @IBAction func MinusPressed(_ sender: UIButton) {
        
        operation(operation: .Subtract)
    }
    
    @IBAction func MultiPressed(_ sender: UIButton) {
        operation(operation: .multiply)
    }
    
    @IBAction func DivisionPressed(_ sender: UIButton) {
        operation(operation: .Division)
    }
    
    @IBAction func PercentPressed(_ sender: UIButton) {
        operation(operation: .percent)
    }
    @IBAction func PlusMinPressed(_ sender: UIButton) {
    }
    
    
    
    func operation(operation: Operation){
        if currentOperation != .Null{
            if runningNumber != ""{
                rightValue = runningNumber
                runningNumber = ""
                
                if currentOperation == .Add{
                    
                    result = "\(Double(leftValue)! + Double(rightValue)!)"
                    
                }else if currentOperation == .Subtract{
                    
                    result = "\(Double(leftValue)! - Double(rightValue)!)"
                    
                }else if currentOperation == .multiply{
                    
                    result = "\(Double(leftValue)! * Double(rightValue)!)"
                    
                }else if currentOperation == .Division{
                    
                    result = "\(Double(leftValue)! / Double(rightValue)!)"
                    
                }else if currentOperation == .percent{
                    result = "\(Double(leftValue)! / 100)"
                }
                leftValue = result
                if(Double(result)!.truncatingRemainder(dividingBy: 1) == 0){
                    result = "\(Int(Double(result)!))"
                }
                outputLbl.text = result
                }
            currentOperation = operation
        }else{
            leftValue = runningNumber
            runningNumber = ""
            currentOperation = operation
        }
    }
}

